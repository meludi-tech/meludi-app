import { useChat } from '@/features/chat/hooks/useChat';
import { useAuthStore } from '@/stores/auth.store';
import { router } from 'expo-router';
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

export default function InboxScreen() {
  const { user } = useAuthStore();
  const { threads, loading } = useChat();

  if (!user) {
    return (
      <View
        style={{
          flex: 1,
          alignItems: 'center',
          justifyContent: 'center',
          paddingHorizontal: 24,
          backgroundColor: '#FFFFFF',
        }}
      >
        <Text style={{ fontSize: 28, fontWeight: '700', marginBottom: 12 }}>
          Mensajes
        </Text>

        <Text
          style={{
            color: '#6B7280',
            textAlign: 'center',
            marginBottom: 24,
            lineHeight: 22,
          }}
        >
          Para ver tus conversaciones necesitas crear cuenta o iniciar sesión.
        </Text>

        <Pressable
          onPress={() => router.push('/(auth)/signup')}
          style={{
            backgroundColor: '#1F3A44',
            paddingHorizontal: 20,
            paddingVertical: 14,
            borderRadius: 14,
            marginBottom: 12,
            width: '100%',
            alignItems: 'center',
          }}
        >
          <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Crear cuenta</Text>
        </Pressable>

        <Pressable
          onPress={() => router.push('/(auth)/login')}
          style={{
            borderWidth: 1.5,
            borderColor: '#111827',
            paddingHorizontal: 20,
            paddingVertical: 14,
            borderRadius: 14,
            width: '100%',
            alignItems: 'center',
          }}
        >
          <Text style={{ color: '#111827', fontWeight: '600' }}>Iniciar sesión</Text>
        </Pressable>
      </View>
    );
  }

  if (loading) {
    return (
      <View style={{ flex: 1, justifyContent: 'center', backgroundColor: '#FFFFFF' }}>
        <ActivityIndicator />
      </View>
    );
  }

  if (!threads.length) {
    return (
      <View style={{ flex: 1, padding: 20, backgroundColor: '#FFFFFF' }}>
        <Text>No tienes mensajes aún</Text>
      </View>
    );
  }

  return (
    <FlatList
      style={{ backgroundColor: '#FFFFFF' }}
      data={threads}
      keyExtractor={(item) => item.id}
      renderItem={({ item }) => (
        <TouchableOpacity
          onPress={() => router.push(`/chat/${item.id}`)}
          style={{
            padding: 16,
            borderBottomWidth: 1,
            borderColor: '#eee',
          }}
        >
          <Text style={{ fontWeight: '600' }}>Conversación</Text>
        </TouchableOpacity>
      )}
    />
  );
}