import {
  createListing,
  uploadListingImages,
} from '@/features/sell/api/createListing';
import { useSellStore } from '@/features/sell/store/useSellStore';
import { supabase } from '@/lib/supabase';
import { useAuthStore } from '@/stores/auth.store';
import * as ImagePicker from 'expo-image-picker';
import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import {
  Alert,
  Image,
  Pressable,
  ScrollView,
  Text,
  TextInput,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function SellScreen() {
  const { user, status } = useAuthStore();

  const {
    title,
    description,
    price,
    brand,
    size,
    condition,
    color,
    images,
    setField,
    addImages,
    reset,
  } = useSellStore();

  const [loading, setLoading] = useState(false);
  const [brands, setBrands] = useState<any[]>([]);
  const [brandQuery, setBrandQuery] = useState('');
  const [showBrandSearch, setShowBrandSearch] = useState(false);

  useEffect(() => {
    if (user) {
      loadBrands();
    }
  }, [user]);

  const loadBrands = async () => {
    const { data } = await supabase
      .from('brands')
      .select('id, name')
      .limit(200);

    setBrands(data || []);
  };

  const filteredBrands = brands.filter((b) =>
    b.name.toLowerCase().includes(brandQuery.toLowerCase())
  );

  const pickImages = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      allowsMultipleSelection: true,
      quality: 0.8,
    });

    if (!result.canceled) {
      const uris = result.assets.map((a: any) => a.uri);
      addImages(uris);
    }
  };

  const handlePublish = async () => {
    if (!user) {
      router.push('/(auth)/signup');
      return;
    }

    if (status !== 'verified') {
      Alert.alert(
        'Verifica tu identidad',
        'Necesitas verificar tu identidad para publicar.',
        [
          { text: 'Cancelar', style: 'cancel' },
          { text: 'Verificar', onPress: () => router.push('/verify') },
        ]
      );
      return;
    }

    if (!title || !price || images.length === 0) {
      Alert.alert('Faltan datos');
      return;
    }

    try {
      setLoading(true);

      const listing = await createListing(
        {
          title,
          description,
          price,
          brand,
          size,
          condition,
          color,
        },
        user.id
      );

      await uploadListingImages(images, listing.id);

      Alert.alert('Publicado 🚀');
      reset();
    } catch (e) {
      console.log(e);
      Alert.alert('Error al publicar');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <SafeAreaView style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
        <View
          style={{
            flex: 1,
            alignItems: 'center',
            justifyContent: 'center',
            paddingHorizontal: 24,
          }}
        >
          <Text style={{ fontSize: 28, fontWeight: '700', marginBottom: 12 }}>
            Vender
          </Text>

          <Text
            style={{
              color: '#6B7280',
              textAlign: 'center',
              marginBottom: 24,
              lineHeight: 22,
            }}
          >
            Para publicar en meludi necesitas crear cuenta o iniciar sesión.
          </Text>

          <Pressable
            onPress={() => router.push('/(auth)/signup')}
            style={{
              backgroundColor: '#1F3A44',
              paddingHorizontal: 20,
              paddingVertical: 14,
              borderRadius: 14,
              marginBottom: 12,
              width: '100%',
              alignItems: 'center',
            }}
          >
            <Text style={{ color: '#FFFFFF', fontWeight: '600' }}>Crear cuenta</Text>
          </Pressable>

          <Pressable
            onPress={() => router.push('/(auth)/login')}
            style={{
              borderWidth: 1.5,
              borderColor: '#111827',
              paddingHorizontal: 20,
              paddingVertical: 14,
              borderRadius: 14,
              width: '100%',
              alignItems: 'center',
            }}
          >
            <Text style={{ color: '#111827', fontWeight: '600' }}>Iniciar sesión</Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#fff' }}>
      <ScrollView contentContainerStyle={{ padding: 20, paddingBottom: 140 }}>
        <Text style={{ fontSize: 28, fontWeight: '700', marginBottom: 20 }}>
          Vender
        </Text>

        <Pressable onPress={pickImages} style={box}>
          <Text>+ Agregar fotos</Text>
        </Pressable>

        <ScrollView horizontal style={{ marginBottom: 20 }}>
          {images.map((uri, i) => (
            <Image
              key={i}
              source={{ uri }}
              style={{
                width: 80,
                height: 80,
                borderRadius: 12,
                marginRight: 10,
              }}
            />
          ))}
        </ScrollView>

        <Input label="Título" value={title} onChange={(v: string) => setField('title', v)} />

        <Text style={{ marginBottom: 6 }}>Marca</Text>

        <Pressable onPress={() => setShowBrandSearch(!showBrandSearch)} style={box}>
          <Text>{brand || 'Seleccionar marca'}</Text>
        </Pressable>

        {showBrandSearch && (
          <View style={{ marginBottom: 16 }}>
            <TextInput
              placeholder="Buscar marca"
              value={brandQuery}
              onChangeText={setBrandQuery}
              style={input}
            />

            {filteredBrands.slice(0, 20).map((b) => (
              <Pressable
                key={b.id}
                onPress={() => {
                  setField('brand', b.name);
                  setShowBrandSearch(false);
                }}
                style={{ paddingVertical: 10 }}
              >
                <Text>{b.name}</Text>
              </Pressable>
            ))}
          </View>
        )}

        <ChipGroup
          label="Talla"
          options={['XS', 'S', 'M', 'L', 'XL']}
          value={size}
          onSelect={(v: string) => setField('size', v)}
        />

        <ChipGroup
          label="Estado"
          options={['Nuevo', 'Muy bueno', 'Bueno', 'Usado']}
          value={condition}
          onSelect={(v: string) => setField('condition', v)}
        />

        <MultiChipGroup
          label="Colores"
          options={['Negro', 'Blanco', 'Beige', 'Azul', 'Rojo', 'Verde']}
          values={color || []}
          onChange={(v: string[]) => setField('color', v)}
        />

        <Input label="Precio" value={price} onChange={(v: string) => setField('price', v)} />

        <Input
          label="Descripción"
          value={description}
          multiline
          onChange={(v: string) => setField('description', v)}
        />

        <Pressable onPress={handlePublish} style={button}>
          <Text style={{ color: '#fff' }}>
            {loading ? 'Publicando...' : 'Publicar'}
          </Text>
        </Pressable>
      </ScrollView>
    </SafeAreaView>
  );
}

const box = {
  borderWidth: 1,
  borderColor: '#E5E7EB',
  borderRadius: 12,
  padding: 14,
  marginBottom: 16,
};

const input = {
  borderWidth: 1,
  borderColor: '#E5E7EB',
  borderRadius: 12,
  padding: 12,
  marginBottom: 10,
};

const button = {
  backgroundColor: '#1F3A44',
  padding: 18,
  borderRadius: 16,
  marginTop: 24,
  alignItems: 'center' as const,
};

function Input({ label, value, onChange, multiline }: any) {
  return (
    <View style={{ marginBottom: 16 }}>
      <Text style={{ marginBottom: 6 }}>{label}</Text>
      <TextInput
        value={value}
        onChangeText={onChange}
        multiline={multiline}
        style={{
          borderWidth: 1,
          borderColor: '#E5E7EB',
          borderRadius: 12,
          padding: 14,
          height: multiline ? 80 : 50,
        }}
      />
    </View>
  );
}

function ChipGroup({ label, options, value, onSelect }: any) {
  return (
    <>
      <Text style={{ marginBottom: 6 }}>{label}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 16 }}>
        {options.map((o: string) => {
          const active = value === o;

          return (
            <Pressable
              key={o}
              onPress={() => onSelect(o)}
              style={{
                paddingHorizontal: 14,
                paddingVertical: 8,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: '#1F3A44',
                backgroundColor: active ? '#1F3A44' : '#fff',
                marginRight: 8,
                marginBottom: 8,
              }}
            >
              <Text style={{ color: active ? '#fff' : '#1F3A44' }}>{o}</Text>
            </Pressable>
          );
        })}
      </View>
    </>
  );
}

function MultiChipGroup({ label, options, values, onChange }: any) {
  return (
    <>
      <Text style={{ marginBottom: 6 }}>{label}</Text>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 16 }}>
        {options.map((o: string) => {
          const active = values.includes(o);

          return (
            <Pressable
              key={o}
              onPress={() => {
                if (active) {
                  onChange(values.filter((v: string) => v !== o));
                } else {
                  onChange([...values, o]);
                }
              }}
              style={{
                paddingHorizontal: 14,
                paddingVertical: 8,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: '#1F3A44',
                backgroundColor: active ? '#1F3A44' : '#fff',
                marginRight: 8,
                marginBottom: 8,
              }}
            >
              <Text style={{ color: active ? '#fff' : '#1F3A44' }}>{o}</Text>
            </Pressable>
          );
        })}
      </View>
    </>
  );
}