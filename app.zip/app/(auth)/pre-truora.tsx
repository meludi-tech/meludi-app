import { supabase } from '@/lib/supabase';
import * as Linking from 'expo-linking';
import { router } from 'expo-router';
import { useState } from 'react';
import { Alert, Pressable, Text, View } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function PreTruora() {
  const [loading, setLoading] = useState(false);

  const handleVerify = async () => {
  if (loading) return;

  try {
    setLoading(true);

    // 1. usuario
    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser();

    if (userError || !user?.id) {
      Alert.alert('Error', 'No encontramos tu sesión.');
      return;
    }

    const userId = user.id;
    console.log('USER ID:', userId);

    // 🔥 2. LLAMADA CORRECTA CON AUTH
    const res = await fetch(
      'https://ijczgrdkvvfmqsddwmle.functions.supabase.co/create-truora-token',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          user_id: userId,
        }),
      }
    );

    const data = await res.json();

    console.log('TRUORA RESPONSE:', data);

    if (!data?.api_key) {
      throw new Error('No se recibió token');
    }

    // 3. guardar estado
    if (data.process_id) {
      await supabase
        .from('profiles')
        .update({
          kyc_process_id: data.process_id,
          kyc_status: 'pending',
        })
        .eq('id', userId);
    }

    // 4. abrir truora
    const url = `https://identity.truora.com/?token=${data.api_key}`;

    console.log('TRUORA URL:', url);

    await Linking.openURL(url);

  } catch (e) {
    console.log('TRUORA ERROR:', e);
    Alert.alert('Error', 'No pudimos iniciar la verificación');
  } finally {
    setLoading(false);
  }
};

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: '#FFFFFF' }}>
      <View
        style={{
          flex: 1,
          paddingHorizontal: 24,
          justifyContent: 'center',
        }}
      >
        <Text
          style={{
            fontSize: 28,
            fontWeight: '700',
            marginBottom: 10,
            color: '#111827',
          }}
        >
          Verificar identidad
        </Text>

        <Text
          style={{
            color: '#6B7280',
            marginBottom: 24,
            lineHeight: 22,
          }}
        >
          Para vender y comprar con seguridad necesitamos verificar tu identidad.
        </Text>

        <Pressable
          onPress={handleVerify}
          disabled={loading}
          style={{
            backgroundColor: '#1F3A44',
            padding: 18,
            borderRadius: 16,
            marginBottom: 12,
            opacity: loading ? 0.6 : 1,
            alignItems: 'center',
          }}
        >
          <Text
            style={{
              color: '#FFFFFF',
              fontWeight: '600',
              fontSize: 16,
            }}
          >
            {loading ? 'Abriendo...' : 'Continuar verificación'}
          </Text>
        </Pressable>

        <Pressable
          onPress={() => router.back()}
          style={{
            borderWidth: 1.5,
            borderColor: '#111827',
            padding: 18,
            borderRadius: 16,
            alignItems: 'center',
          }}
        >
          <Text
            style={{
              color: '#111827',
              fontWeight: '500',
            }}
          >
            Más tarde
          </Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}