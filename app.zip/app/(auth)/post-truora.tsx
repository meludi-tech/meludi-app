import { supabase } from '@/lib/supabase';
import { router } from 'expo-router';
import { useEffect, useState } from 'react';
import { ActivityIndicator, Text } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

export default function PostTruora() {
  const [status, setStatus] = useState<'pending' | 'verified' | 'rejected'>('pending');

  useEffect(() => {
    let interval: any;

    const checkStatus = async () => {
      const {
        data: { user },
      } = await supabase.auth.getUser();

      if (!user) return;

      const { data } = await supabase
        .from('profiles')
        .select('kyc_status')
        .eq('id', user.id)
        .single();

      if (data?.kyc_status) {
        setStatus(data.kyc_status);

        if (data.kyc_status === 'verified') {
          clearInterval(interval);

          // 🔥 volver a la app automáticamente
          setTimeout(() => {
            router.replace('/');
          }, 1000);
        }
      }
    };

    checkStatus();

    interval = setInterval(checkStatus, 3000);

    return () => clearInterval(interval);
  }, []);

  return (
    <SafeAreaView style={{ flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' }}>
      {status === 'pending' && (
        <>
          <ActivityIndicator size="large" />
          <Text style={{ marginTop: 16, fontSize: 18, fontWeight: '600' }}>
            Verificando identidad
          </Text>
          <Text style={{ color: '#6B7280', marginTop: 6 }}>
            Esto puede tardar unos minutos.
          </Text>
        </>
      )}

      {status === 'verified' && (
        <Text style={{ fontSize: 20, fontWeight: '600' }}>
          Verificación completada 🎉
        </Text>
      )}

      {status === 'rejected' && (
        <Text style={{ fontSize: 18, color: 'red' }}>
          No pudimos verificar tu identidad
        </Text>
      )}
    </SafeAreaView>
  );
}